#include "mainwindow.h"
#include <QApplication>
//添加头文件
#include <QSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QString>
#include <QFile>
#include <QDebug>
#include <QVariantList>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");//添加数据库驱动
    database.setDatabaseName("MyDataBase.db");//设置数据库名称
    database.setUserName("root");  //设置数据库登录用户名
    database.setPassword("123456");//设置数据库登录密码
    //打开数据库
    if(database.open())
    {
        qDebug()<<"Database Opened";

        /*
        QString create_sql = "create table student (id int primary key, name varchar(30), age int)";
        QString select_max_sql = "select max(id) from student";
        QString insert_sql = "insert into student values (?, ?, ?)";
        QString update_sql = "update student set name = :name where id = :id";
        QString select_sql = "select id, name from student";
        QString select_all_sql = "select * from student";
        QString delete_sql = "delete from student where id = ?";
        QString clear_sql = "delete from student";
        */
        //创建表成员
        QString create_sql = "create table star (id int primary key, name varchar(30), age int,address varchar(30))"; //创建数据表
        //插入数据
        QString insert_sql = "insert into star values(?,?,?,?)";
        //查询全部数据
        QString select_all_sql = "select * from star";
        QSqlQuery sql_query;//QSqlQuery类提供执行和操作的SQL语句的方法
        sql_query.prepare(create_sql); //创建表
        if(!sql_query.exec()) //查看创建表是否成功
        {
            qDebug()<<QObject::tr("Table Create failed");
            qDebug()<<sql_query.lastError();
        }
        else
        {
            qDebug()<< "Table Created" ;
            //插入数据
            sql_query.prepare(insert_sql);

            QVariantList GroupIDs;
            GroupIDs.append(0);
            GroupIDs.append(1);
            GroupIDs.append(2);
            GroupIDs.append(3);
            GroupIDs.append(4);


            QVariantList GroupNames;
            GroupNames.append("赵丽颖");
            GroupNames.append("杨幂");
            GroupNames.append("郑爽");
            GroupNames.append("可乐");
            GroupNames.append("孙耀威");

            QVariantList GroupAges;
            GroupAges.append(33);
            GroupAges.append(35);
            GroupAges.append(25);
            GroupAges.append(1);
            GroupAges.append(42);

            QVariantList GroupAddress;
            GroupAddress.append("成都");
            GroupAddress.append("北京");
            GroupAddress.append("天津");
            GroupAddress.append("上海");
            GroupAddress.append("深圳");


            sql_query.addBindValue(GroupIDs);
            sql_query.addBindValue(GroupNames);
            sql_query.addBindValue(GroupAges);
            sql_query.addBindValue(GroupAddress);

            if(!sql_query.execBatch())
            {
                qDebug()<<sql_query.lastError();
            }
            else
            {
                qDebug()<<"插入记录成功";
            }

            //查询所有记录
            sql_query.prepare(select_all_sql);
            if(!sql_query.exec())
            {
                qDebug()<<sql_query.lastError();//查询失败
            }
            else
            {
                //检索下一个
                while(sql_query.next())
                {
                    int id = sql_query.value(0).toInt();
                    QString name = sql_query.value(1).toString();
                    int age = sql_query.value(2).toInt();
                    QString address = sql_query.value(3).toString();
                    qDebug()<<QString("ID:%1  Name:%2  Age:%3  Address:%4").arg(id).arg(name).arg(age).arg(address);

                    //删除数据
                    /*sql_query.prepare(delete_sql);
                    sql_query.addBindValue(max_id);
                    if(!sql_query.exec())
                    {
                        qDebug()<<sql_query.lastError();
                    }
                    else
                    {
                        qDebug()<<"deleted!";
                    }

                    //清空表
                    sql_query.prepare(clear_sql);
                    if(!sql_query.exec())
                    {
                        qDebug()<<sql_query.lastError();
                    }
                    else
                    {
                        qDebug()<<"cleared";
                    }*/
                }
            }
        }

        QSqlQuery query;//QSqlQuery类提供执行和操作的SQL语句的方法
        QString createStudent = "create table student (id int primary key, name varchar(30), sex varchar(30),score int)"; //创建数据表
        //插入数据
        QString insertStudent = "insert into student values(?,?,?,?)";
        //查询全部数据
        QString selectAllStudent = "select * from student";
        //按条件查询
        QString selectStudent = "select id, name from student";
        query.prepare(createStudent); //创建表.prepare(create_sql); //创建表
        if(!query.exec()) //查看创建表是否成功
        {
            qDebug()<<QObject::tr("Table Create failed");
            qDebug()<<query.lastError();
        }
        else
        {
            qDebug()<< "Table Created" ;
            //插入数据
            //query.prepare(insertStudent);
            query.prepare("INSERT INTO student (id, name, sex , score) "
                              "VALUES (?, ?, ?, ?)");

            QVariantList GroupIDs;
            GroupIDs.append(0);
            GroupIDs.append(1);
            GroupIDs.append(2);
            GroupIDs.append(3);
            GroupIDs.append(4);


            QVariantList GroupNames;
            GroupNames.append("赵丽颖");
            GroupNames.append("杨幂");
            GroupNames.append("郑爽");
            GroupNames.append("可乐");
            GroupNames.append("孙耀威");

            QVariantList GroupSex;
            GroupSex.append("女");
            GroupSex.append("女");
            GroupSex.append("女");
            GroupSex.append("母");
            GroupSex.append("男");

            QVariantList GroupScore;
            GroupScore.append(90);
            GroupScore.append(80);
            GroupScore.append(70);
            GroupScore.append(60);
            GroupScore.append(50);


            query.addBindValue(GroupIDs);
            query.addBindValue(GroupNames);
            query.addBindValue(GroupSex);
            query.addBindValue(GroupScore);

            if(!query.execBatch())
            {
                qDebug()<<query.lastError();
            }
            else
            {
                qDebug()<<"插入记录成功";
            }

            //查询所有记录
            query.prepare(selectAllStudent);
            if(!query.exec())
            {
                qDebug()<<query.lastError();//查询失败
            }
            else
            {
                qDebug()<<"查询所有";
                //检索下一个
                while(query.next())
                {
                    int id = query.value(0).toInt();
                    QString name = query.value(1).toString();
                    QString sex = query.value(2).toString();
                    int score = query.value(3).toInt();
                    qDebug()<<QString("ID:%1  Name:%2  Sex:%3  Score:%4").arg(id).arg(name).arg(sex).arg(score);
                }
            }
            //按条件查询id,name
            query.prepare(selectStudent);
            if(!query.exec())
            {
                qDebug()<<query.lastError();//查询失败
            }
            else
            {
                qDebug()<<"按条件查询id,name";
                //检索下一个
                while(query.next())
                {
                    int id = query.value(0).toInt();
                    QString name = query.value(1).toString();
                    //QString sex = query.value(2).toString();
                    //int score = query.value(3).toInt();
                    //qDebug()<<QString("ID:%1  Name:%2  Sex:%3  Score:%4").arg(id).arg(name).arg(sex).arg(score);
                    qDebug()<<QString("ID:%1  Name:%2").arg(id).arg(name);
                }
            }
        }
    }
    database.close();
    //删除数据库
    //QFile::remove("database.db");

    w.show();

    return a.exec();
}
