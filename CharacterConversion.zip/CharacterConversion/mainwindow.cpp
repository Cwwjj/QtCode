#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QStringToString();

    StringToQString();

    numberToQString(234,10);

    doubleToQString(12.3456789,'g',4);

    stringToCharPointer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

/*******************************************************
* @brief        QString转String
* @param        []
* @return       void
* @author       xiaolei
* @data         2019-11-03
* @note         -
*******************************************************/
void MainWindow::QStringToString()
{
    QString qstr(tr("hello"));
    string str1=qstr.toStdString(); //QString转String

    string str2="hello";
    if(str1==str2)
    {
        qDebug()<<"string is true!";
    }
    else
    {
        qDebug()<<"string is false!";
    }
}

/*******************************************************
* @brief        String转QString
* @param        []
* @return       void
* @author       xiaolei
* @data         2019-11-03
* @note         -
*******************************************************/
void MainWindow::StringToQString()
{
    string str="hello";
    QString qstr=QString::fromStdString(str);
    qDebug()<<"qstr is:"<<qstr;
}

/*******************************************************
* @brief        double转QString
* @param        []
* @return       void
* @author       xiaolei
* @data         2019-11-03
* @note         -
*******************************************************/
void MainWindow::doubleToQString(double value,char f, int prec)
{
    QString qstr=QString::number(value,f,prec);
    qDebug()<<"qstr:"<<qstr;
}

/*******************************************************
* @brief        string转char*
* @param        []
* @return       void
* @author       xiaolei
* @data         2019-11-03
* @note         -
*******************************************************/
void MainWindow::stringToCharPointer()
{
    string str="hello";
    const char *p=str.c_str();
    const char *test="hello";
    if(*p==*test)
    {
        qDebug()<<"string转char*成功！";
    }
}


