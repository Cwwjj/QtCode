#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <iostream>
#include <QDebug>

using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void QStringToString();
    void StringToQString();

    /*******************************************************
    * @brief        模板函数：数字转QString
    * @param        []
    * @return       void
    * @author       xiaolei
    * @data         2019-11-03
    * @note         支持类型：int、uint、long、ulong、longlong、ulonglong
    *******************************************************/
    template <class T>
    void numberToQString(T value,int base)
    {
        QString qstr=QString::number(value,base);
        qDebug()<<"qstr:"<<qstr;
    }

    void doubleToQString(double value,char f='g', int prec=6);
    void stringToCharPointer();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
