/*******************************************************
* @brief        按钮贴图
* @author       xiaolei
* @copyright    -
* @version      V1.0
* @data         2019-11-13
* @note         1、按钮大小需要适应icon的大小
* @note         2、通过设置样式表来改变按钮的背景色
* @note         3、按下按钮显示文本
*******************************************************/
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle(tr("按钮贴图"));
    this->resize(320,240);
    QWidget *centralWidget = new QWidget(this);
    this->setCentralWidget(centralWidget);

    loveBtn=new QPushButton(centralWidget);
    loveBtn->setIconSize(QSize(64,64));
    loveBtn->setFixedSize(QSize(50,50));
    loveBtn->setGeometry(QRect(135,95,50,50));  //设置几何坐标
    loveBtn->setStyleSheet("QPushButton"
                           "{"
                           "background-image: url(:/images/love.png);"
                           "background-color: rgba(255, 255, 255,0);"
                           "border-style:outset;"
                           "border-color:rgba(255,255,255,0);"
                           "border-radius:4px;"
                           "}"
                           "QPushButton:hover{"
                           "background-color: rgba(255, 255, 255,200);"
                           "}"
                           "QPushButton:pressed{"
                           " background-color: rgba(95, 95, 95,100);"
                           "border-color:rgba(255,255,255,30);"
                           "border-style:inset;"
                           "color:rgba(0,0,0,100);"
                          " }");

    loveLe=new QLineEdit(centralWidget);
    loveLe->setGeometry(QRect(135,155,50,50));
    loveLe->setReadOnly(true);  //设置只读
    loveLe->setFont(QFont("微软雅黑",16));
    loveLe->setAlignment(Qt::AlignCenter);
    loveLe->setVisible(false);  //设置不可视
    loveLe->setStyleSheet("QLineEdit"
                          "{"
                          "border-color:rgba(255,255,255,0);"
                          "border-radius:5px;"
                          "color:rgb(255,200,255);"
                          "}");

    connect(loveBtn,&QPushButton::clicked,this,&MainWindow::showLove);
}

MainWindow::~MainWindow()
{

}

/*******************************************************
* @brief        显示文本
* @param        []
* @return       void
* @author       xiaolei
* @data         2019-11-13
* @note         -
*******************************************************/
void MainWindow::showLove()
{
    loveLe->setVisible(true);   //设置可视
    loveLe->setText(tr("love"));
}
