#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle(tr("QT多线程"));
    this->resize(640,480);
    centralWidget=new QWidget(this);
    this->setCentralWidget(centralWidget);

    layout=new QHBoxLayout;

    btn1=new QPushButton(centralWidget);
    btn1->setText(tr("开启线程1"));
    btn1->setMaximumSize(100,35);

    btn2=new QPushButton(centralWidget);
    btn2->setText(tr("开启线程2"));
    btn2->setMaximumSize(100,35);

    btn3=new QPushButton(centralWidget);
    btn3->setText(tr("开启线程3"));
    btn3->setMaximumSize(100,35);

    btn4=new QPushButton(centralWidget);
    btn4->setText(tr("退出"));
    btn4->setMaximumSize(100,35);

    layout->addWidget(btn1);
    layout->addWidget(btn2);
    layout->addWidget(btn3);
    layout->addWidget(btn4);

    layout->setSpacing(10);
    centralWidget->setLayout(layout);

    thread1.setMessage(tr("A"));
    thread2.setMessage(tr("B"));
    thread3.setMessage(tr("C"));

    connect(btn1,&QPushButton::clicked,this,&MainWindow::startOrStopThread1);
    connect(btn2,&QPushButton::clicked,this,&MainWindow::startOrStopThread2);
    connect(btn3,&QPushButton::clicked,this,&MainWindow::startOrStopThread3);
    connect(btn4,&QPushButton::clicked,this,&MainWindow::close);
}

MainWindow::~MainWindow()
{

}

void MainWindow::closeEvent(QCloseEvent *event)
{
    thread1.stop();
    thread2.stop();
    thread3.stop();
    thread1.wait();
    thread2.wait();
    thread3.wait();
    event->accept();
}

void MainWindow::startOrStopThread1()
{
    if(thread1.isRunning())
    {
        btn1->setText(tr("关闭线程1"));
        thread1.stop();
        btn1->setText(tr("开启线程1"));
    }
    else
    {
        btn1->setText(tr("开启线程1"));
        thread1.start();
        btn1->setText(tr("关闭线程1"));
    }
}

void MainWindow::startOrStopThread2()
{
    if(thread2.isRunning())
    {
        btn2->setText(tr("关闭线程2"));
        thread2.stop();
        btn2->setText(tr("开启线程2"));
    }
    else
    {
        btn2->setText(tr("开启线程2"));
        thread2.start();
        btn2->setText(tr("关闭线程2"));
    }
}

void MainWindow::startOrStopThread3()
{
    if(thread3.isRunning())
    {
        btn3->setText(tr("关闭线程2"));
        thread3.stop();
        btn3->setText(tr("开启线程2"));
    }
    else
    {
        btn3->setText(tr("开启线程2"));
        thread3.start();
        btn3->setText(tr("关闭线程2"));
    }
}

void MainWindow::close()
{
    exit(0);
}


