#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QPushButton>
#include <QDebug>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QCloseEvent>
#include "thread.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *event);

private slots:
    void startOrStopThread1();
    void startOrStopThread2();
    void startOrStopThread3();
    void close();

private:
    QWidget *centralWidget;
    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;
    QPushButton *btn4;

    QHBoxLayout *layout;

    Thread thread1;
    Thread thread2;
    Thread thread3;
};

#endif // MAINWINDOW_H
